
  <html ng-app="MyApplication">
  <head>
  <script src="<?php echo base_url('asset/angularjs/angular.min.js')?>"></script>
  <script src="<?php echo base_url('asset/angularjs/angular-sanitize.min.js') ?>"></script>
  <script src="<?php echo base_url('folder/app.js')?>"></script>
  <!-- <link rel="stylesheet" href="<?php echo base_url('folder/login_style.css')?>"> -->
  <link rel="stylesheet" href="<?php echo base_url('folder/style_table.css')?>">
<script type="text/javascript">
  var BASEURL='<?php echo base_url();?>';
</script>

  
  </head>
 
  <body>
  
        <div ng-controller="Controller1">

            <form ng-submit="CLIENTFORM()">
              <div class="login-box">

                <div class="container">
                  <h1>Register</h1>
                  <p>Please fill in this form to create an account.</p>
                  <hr>

                 <div class="container">
                        <table>
                              <tr>
                              <th>Patient information</th>
                              </tr>  
                              
                              <tr>
                              <td>Lastname:<input type="text" name="LASTNAME" ng-model="LOGIN.LASTNAME"required="required"></td>


                              <td>Firstname:<input type="text" name="FIRSTNAME" ng-model="LOGIN.FIRSTNAME"required="required">
                              </td>


                              <td>Middlename:<input type="text"  name="MIDDLENAME" ng-model="LOGIN.MIDDLENAME" required="required"></td> 


                              <td>Suffix:<input type="text" name="SUFFIX" ng-model="LOGIN.SUFFIX" required="required"></td>


                              </tr>
                              <tr>


                              <td>Username:<input type="text" name="USERNAME" ng-model="LOGIN.USERNAME" required="required">
                               </td>

                              <td>Password:<input type="password" name="PASSWORD" ng-model="LOGIN.PASSWORD" required="required">
                              </td>

 
                                     

                        </table> 

                      </div>
                 

                   <button type="submit" class="button" ><span>SAVE</span></button>
                
                 </div>
 
               </div>
            </form>

         </body>
</html>

    

      



       