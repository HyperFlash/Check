<?php
	defined('BASEPATH') OR exit ('NO direct script access allowed');

	class M_login extends CI_Model
	{
		function __construct(){$this->load->database();}

 	// 	function submit_client_registration()
		// {

		// 	$_POST += json_decode(file_get_contents('php://input'), true);
		// 	$this->db->insert('client_information',array(
		// 		'LASTNAME'=>$_POST['LASTNAME'],
		// 		'FIRSTNAME'=>$_POST['FIRSTNAME'],
		// 		'MIDDLENAME'=>$_POST['MIDDLENAME'],
		// 		'SUFFIX'=>$_POST['SUFFIX'],
		// 		'USERNAME'=>$_POST['USERNAME'],
		// 		'PASSWORD'=>$_POST['PASSWORD'],

		// 	)); 

		// 	echo "string";
		// }
 
	}


?>