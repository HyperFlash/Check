<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('page_client_register');
		$this->load->view('page_login');
		$this->load->view('page_patient_registrationdata_add');
		$this->load->view('page_patient_registration_data');
		$this->load->view('page_patient_registration');



	}
	public function submit_form_registration ()
	{
		$this->load->model('M_patients');
		$this->M_patients->submit_form_registration();
		$this->load->view('page_patient_registration_data');


	}

	public function submit_client_registration ()
	{
		$this->load->model('M_patients');
		$this->M_patients->submit_client_registration();
		$this->load->view('page_client_register');


	}

	public function submit(){
		$USERNAME = $this->input->post('USERNAME');
		$PASSWORD = $this->input->post('PASSWORD');	
		
		$result=$this->model->login($USERNAME, $PASSWORD );
		
		if ($result)  {
			$this->session->set_userdata('login_state', TRUE);
			// $this->session->set_userdata('auth', $this->model->get_role($result->Role));
			// $this->session->set_userdata('auth', $this->model->get_role($result->Role));
			$this->session->set_userdata('user', $result);
			$this->load->view('page_patient_registration_data');
		} else {
			$this->load->view('page_login');    
		}
	}

	

	 public function new_patient()
	{
   
 	 $this->load->view('page_patient_registration_add',array('id'=>0));
  	}
	//updateform
 //  	 public function update_patient_record()
	// {
   
 // 	 $this->load->view('page_patient_registration');
 // 	  // $this->load->view('page_patient_registration_add',array('id'=>0));
 //  	}





  	public function client_register()
	{
   
 	 $this->load->view('page_client_register',array('id'=>0));
  	}

  	public function view_patient()
	{
   
 	 $this->load->view('page_patient_registration_data');
  	}

  	public function in_patient_record()
	{
   
 	 $this->load->view('page_in_patient_record');
  	} 
  	public function out_patient_record()
	{
   
 	 $this->load->view('page_out_patient_record');
  	}
  		public function log_in()
	{
   
 	 $this->load->view('page_login');
  	}
  		



   public function search_patient()
   {
   	$this->load->model('M_patients');
        $data=$this->M_patients->search_patient();
        echo json_encode($data);
    }
 
 	public function edit_patient($pid)
 	{
 		
 		$this->load->view('page_patient_registration',array('id'=>$pid));
	
	}

	 	public function edit_patientdata()
 	{
 		$this->load->model('M_patients');
 		 $data=$this->M_patients->edit_patientdata();
 		 echo json_encode($data);

	}   

 
	public function delete_patientdata()
	{
		$this->load->model("M_patients");  
        $this->M_patients->delete_patientdata();  
           echo 'Data Deleted';  
	}


	// public function delete_patientdata()
	// {	 
	// 	$this->load->database();
 //        $this->db->where('id', $id);
	// 	$this->db->delete('patient_information');
	// 	echo json_encode(['success'=>true]);

	// }

	 
	public function UpdatePatient()
	{
		$this->load->model('M_patients');
		$id = $this->uri->segment(3);
		
		$data = array(
			'LASTNAME' => $this->input->post('LASTNAME'),
			'FIRSTNAME' => $this->input->post('FIRSTNAME'),
			'MIDDLENAME' => $this->input->post('MIDDLENAME'),
			'SUFFIX' => $this->input->post('SUFFIX'),
			'SEX' => $this->input->post('SEX'),
			'CIVIL_STATUS' => $this->input->post('CIVIL_STATUS'),
			'DATE_OF_BIRTH' => $this->input->post('DATE_OF_BIRTH'),
			'NBCONDITION' => $this->input->post('NBCONDITION'),
			'FILE_NO' => $this->input->post('FILE_NO'),
			'DATEREG' => $this->input->post('DATEREG'),
			'OCCUPATION' => $this->input->post('OCCUPATION'),
			'RELIGION' => $this->input->post('RELIGION'),
			'NATIONALITY' => $this->input->post('NATIONALITY'),
			'TELNO' => $this->input->post('TELNO'),
			'PLACE_BIRTH' => $this->input->post('PLACE_BIRTH'),
			'NO_STREET' => $this->input->post('NO_STREET'),
			'PROVINCE' => $this->input->post('PROVINCE'),
			'CITY_MUNICIPALITY' => $this->input->post('CITY_MUNICIPALITY'),
			'BARANGAY' => $this->input->post('BARANGAY'),
			'ZIPCODE' => $this->input->post('ZIPCODE'),
			'COMPANY' => $this->input->post('COMPANY'),
			'ADDRESS' => $this->input->post('ADDRESS'),
			'HEALTH_INSURANCE' => $this->input->post('HEALTH_INSURANCE'),
			'HEALTH_INSURANCE_ADDRESS' => $this->input->post('HEALTH_INSURANCE_ADDRESS'),
			'RH' => $this->input->post('RH'),
			'CREDIT_LIMIT' => $this->input->post('CREDIT_LIMIT'),
			'SENIOR_CITIZEN_NO' => $this->input->post('SENIOR_CITIZEN_NO'),
			'MEDICARE' => $this->input->post('MEDICARE'),
			'PLAN' => $this->input->post('PLAN'),
			'BLOOD_TYPE' => $this->input->post('BLOOD_TYPE'),
			'ALLERGIES' => $this->input->post('ALLERGIES'),
			'SC_DATE_ISSUE' => $this->input->post('SC_DATE_ISSUE'),
			'FATHER_NAME' => $this->input->post('FATHER_NAME'),
			'FATHER_ADDRESS' => $this->input->post('FATHER_ADDRESS'),
			'FATHER_TELEPHONE_NO' => $this->input->post('FATHER_TELEPHONE_NO'),
			'MOTHER_NAME' => $this->input->post('MOTHER_NAME'),
			'MOTHER_ADDRESS' => $this->input->post('MOTHER_ADDRESS'),
			'MOTHER_TELEPHONE_NO' => $this->input->post('MOTHER_TELEPHONE_NO'),
			'SPOUSE_NAME' => $this->input->post('SPOUSE_NAME'),
			'SPOUSE_ADDRESS' => $this->input->post('SPOUSE_ADDRESS'),
			'SPOUSE_TELEPHONE_NO' => $this->input->post('SPOUSE_TELEPHONE_NO'),
			'SPOUSE_OCCUPATION' => $this->input->post('SPOUSE_OCCUPATION'),
			'EMERGENCY_NAME' => $this->input->post('EMERGENCY_NAME'),
			'EMERGENCY_ADDRESS' => $this->input->post('EMERGENCY_ADDRESS'),
			'EMERGENCY_RELATION' => $this->input->post('EMERGENCY_RELATION'),
			'EMERGENCY_TELEPHONE_NO' => $this->input->post('EMERGENCY_TELEPHONE_NO'),
			'MI_PHIC_NO' => $this->input->post('MI_PHIC_NO'),
			'MI_LASTNAME' => $this->input->post('MI_LASTNAME'),
			'MI_FIRSTNAME' => $this->input->post('MI_FIRSTNAME'),
			'MI_MIDDLENAME' => $this->input->post('MI_MIDDLENAME'),
			'MI_SUFFIX' => $this->input->post('MI_SUFFIX'),
			'MI_SEX' => $this->input->post('MI_SEX'),
			'MI_DOB' => $this->input->post('MI_DOB'),
			'MI_MEMBER_RELATION' => $this->input->post('MI_MEMBER_RELATION'),
			'MI_MEMBERSHIP_TYPE' => $this->input->post('MI_MEMBERSHIP_TYPE'),
			'MI_EMAIL' => $this->input->post('MI_EMAIL'),
			'MI_CONTACT' => $this->input->post('MI_CONTACT'),
			'AM_NO_STREET' => $this->input->post('AM_NO_STREET'),
			'AM_MUNICIPALITY_CITY' => $this->input->post('AM_MUNICIPALITY_CITY'),
			'AM_BARANGAY' => $this->input->post('AM_BARANGAY'),
			'AM_PROVINCE' => $this->input->post('AM_PROVINCE'),
			'AM_ZIPCODE' => $this->input->post('AM_ZIPCODE'),
			'PHIC_PE_NAME' => $this->input->post('PHIC_PE_NAME'),
			'PHIC_PE_ADDRESS' => $this->input->post('PHIC_PE_ADDRESS'),
			'PHIC_PE_CONTACT_NO' => $this->input->post('PHIC_PE_CONTACT_NO'),
			'PHIC_PE_PIN' => $this->input->post('PHIC_PE_PIN')
			
		);
		$this->M_patients->UpdatePaitentData($data,$id);
		$this->load->view('page_patient_registration_data');
	}
	
	public function Deletecont()
	{
		$this->load->model('M_patients');
		$id =  $this->uri->segment(3);
		$this->M_patients->deleteData($id);
		$this->load->view('page_patient_registration_data');
	}


	

	 public function login(){
        // header('Content-Type', 'application/json');
        $_POST = json_decode(file_get_contents("php://input"));
        $data = array(
            'USERNAME' => $_POST['USERNAME'],
            'PASSWORD' => $_POST['PASSWORD'],
            );
        $this->load->model('M_patients');
        $result = $this->M_patients->login($data);

        if($result == TRUE){
            $this->load->view('page_patient_registration_data');
        } else {
            $this->load->view('404');
        }

	}


	
	
}
